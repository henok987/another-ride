const { Driver } = require('../models/userModels');
const { crudController } = require('./basic.crud');
const { Pricing } = require('../models/pricing');
const geolib = require('geolib');

const base = crudController(Driver);

async function setAvailability(req, res) {
  try {
    const driverId = String((((req.user && req.user.id) !== undefined && (req.user && req.user.id) !== null) ? req.user.id : req.params.id) || '');
    if (!driverId) return res.status(400).json({ message: 'Invalid driver id' });
    const d = await Driver.findByIdAndUpdate(driverId, { $set: { available: !!req.body.available } }, { new: true, upsert: true, setDefaultsOnInsert: true });
    if (!d) return res.status(404).json({ message: 'Not found' });
    return res.json(d);
  } catch (e) { return res.status(500).json({ message: e.message }); }
}

async function updateLocation(req, res) {
  try {
    const driverId = String((((req.user && req.user.id) !== undefined && (req.user && req.user.id) !== null) ? req.user.id : req.params.id) || '');
    if (!driverId) return res.status(400).json({ message: 'Invalid driver id' });
    const { latitude, longitude, bearing } = req.body;
    
    const locationUpdate = { latitude, longitude };
    if (bearing !== undefined && bearing >= 0 && bearing <= 360) {
      locationUpdate.bearing = bearing;
    }
    
    const d = await Driver.findByIdAndUpdate(driverId, { $set: { lastKnownLocation: locationUpdate } }, { new: true, upsert: true, setDefaultsOnInsert: true });
    if (!d) return res.status(404).json({ message: 'Not found' });
    return res.json(d);
  } catch (e) { return res.status(500).json({ message: e.message }); }
}

async function availableNearby(req, res) {
  try {
    const { latitude, longitude, radiusKm = 5, vehicleType } = req.query;
    const all = await Driver.find({ available: true, ...(vehicleType ? { vehicleType } : {}) });
    const nearby = all.filter(d => d.lastKnownLocation && distanceKm(d.lastKnownLocation, { latitude: +latitude, longitude: +longitude }) <= +radiusKm);
    
    // Enhanced driver information for passengers
    const response = nearby.map(driver => ({
      _id: driver._id,
      driverId: driver._id,
      name: driver.name,
      phone: driver.phone,
      vehicleType: driver.vehicleType,
      // Vehicle information
      carPlate: driver.carPlate,
      carModel: driver.carModel,
      carColor: driver.carColor,
      // Rating information
      rating: driver.rating || 5.0,
      ratingCount: driver.ratingCount || 0,
      // Location with bearing
      lastKnownLocation: {
        latitude: driver.lastKnownLocation.latitude,
        longitude: driver.lastKnownLocation.longitude,
        bearing: driver.lastKnownLocation.bearing || null
      },
      // Distance from passenger
      distanceKm: distanceKm(driver.lastKnownLocation, { latitude: +latitude, longitude: +longitude })
    }));
    
    // Sort by distance (closest first)
    response.sort((a, b) => a.distanceKm - b.distanceKm);
    
    return res.json(response);
  } catch (e) { return res.status(500).json({ message: `Failed to find nearby drivers: ${e.message}` }); }
}

function distanceKm(a, b) {
  if (!a || !b || a.latitude == null || b.latitude == null) return Number.POSITIVE_INFINITY;
  const toRad = (v) => (v * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);
  const aHarv = Math.sin(dLat/2)**2 + Math.sin(dLon/2)**2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(aHarv));
}

// Fare estimation for passengers before booking
async function estimateFareForPassenger(req, res) {
  try {
    const { vehicleType = 'mini', pickup, dropoff } = req.body;
    
    if (!pickup || !dropoff) {
      return res.status(400).json({ message: 'Pickup and dropoff locations are required' });
    }

    if (!pickup.latitude || !pickup.longitude || !dropoff.latitude || !dropoff.longitude) {
      return res.status(400).json({ message: 'Valid latitude and longitude are required for both pickup and dropoff' });
    }

    // Calculate distance
    const distanceKm = geolib.getDistance(
      { latitude: pickup.latitude, longitude: pickup.longitude },
      { latitude: dropoff.latitude, longitude: dropoff.longitude }
    ) / 1000;

    // Get pricing for vehicle type
    const pricing = await Pricing.findOne({ vehicleType, isActive: true }).sort({ updatedAt: -1 });
    
    if (!pricing) {
      return res.status(404).json({ message: `No pricing found for vehicle type: ${vehicleType}` });
    }

    // Calculate fare breakdown
    const fareBreakdown = {
      base: pricing.baseFare,
      distanceCost: distanceKm * pricing.perKm,
      timeCost: 0, // Could be calculated based on estimated travel time
      waitingCost: 0, // Could be calculated based on waiting time
      surgeMultiplier: pricing.surgeMultiplier
    };

    const estimatedFare = (fareBreakdown.base + fareBreakdown.distanceCost + fareBreakdown.timeCost + fareBreakdown.waitingCost) * fareBreakdown.surgeMultiplier;

    res.json({
      vehicleType,
      distanceKm: Math.round(distanceKm * 100) / 100, // Round to 2 decimal places
      estimatedFare: Math.round(estimatedFare * 100) / 100,
      fareBreakdown,
      pricing: {
        baseFare: pricing.baseFare,
        perKm: pricing.perKm,
        perMinute: pricing.perMinute,
        waitingPerMinute: pricing.waitingPerMinute,
        surgeMultiplier: pricing.surgeMultiplier
      }
    });
  } catch (e) {
    res.status(500).json({ message: `Failed to estimate fare: ${e.message}` });
  }
}

// Fare estimation for drivers before accepting booking
async function estimateFareForDriver(req, res) {
  try {
    const { bookingId } = req.params;
    const driverId = req.user.id;

    // Get the booking details
    const { Booking } = require('../models/bookingModels');
    const booking = await Booking.findById(bookingId);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    // Check if driver is assigned to this booking
    if (booking.driverId && booking.driverId !== driverId) {
      return res.status(403).json({ message: 'You are not assigned to this booking' });
    }

    // Calculate distance if not already calculated
    let distanceKm = booking.distanceKm;
    if (!distanceKm && booking.pickup && booking.dropoff) {
      distanceKm = geolib.getDistance(
        { latitude: booking.pickup.latitude, longitude: booking.pickup.longitude },
        { latitude: booking.dropoff.latitude, longitude: booking.dropoff.longitude }
      ) / 1000;
    }

    // Get pricing for vehicle type
    const pricing = await Pricing.findOne({ vehicleType: booking.vehicleType, isActive: true }).sort({ updatedAt: -1 });
    
    if (!pricing) {
      return res.status(404).json({ message: `No pricing found for vehicle type: ${booking.vehicleType}` });
    }

    // Calculate fare breakdown
    const fareBreakdown = {
      base: pricing.baseFare,
      distanceCost: distanceKm * pricing.perKm,
      timeCost: 0,
      waitingCost: 0,
      surgeMultiplier: pricing.surgeMultiplier
    };

    const estimatedFare = (fareBreakdown.base + fareBreakdown.distanceCost + fareBreakdown.timeCost + fareBreakdown.waitingCost) * fareBreakdown.surgeMultiplier;

    // Calculate driver earnings (after commission)
    const { Commission } = require('../models/commission');
    const commission = await Commission.findOne({ isActive: true }).sort({ createdAt: -1 });
    const commissionRate = commission ? commission.percentage : 15; // Default 15%
    
    const grossFare = estimatedFare;
    const commissionAmount = (grossFare * commissionRate) / 100;
    const netEarnings = grossFare - commissionAmount;

    res.json({
      bookingId: booking._id,
      vehicleType: booking.vehicleType,
      distanceKm: Math.round(distanceKm * 100) / 100,
      estimatedFare: Math.round(estimatedFare * 100) / 100,
      fareBreakdown,
      driverEarnings: {
        grossFare: Math.round(grossFare * 100) / 100,
        commissionRate: commissionRate,
        commissionAmount: Math.round(commissionAmount * 100) / 100,
        netEarnings: Math.round(netEarnings * 100) / 100
      },
      pickup: booking.pickup,
      dropoff: booking.dropoff
    });
  } catch (e) {
    res.status(500).json({ message: `Failed to estimate fare for driver: ${e.message}` });
  }
}

module.exports = { 
  ...base, 
  setAvailability, 
  updateLocation, 
  availableNearby, 
  estimateFareForPassenger, 
  estimateFareForDriver 
};

